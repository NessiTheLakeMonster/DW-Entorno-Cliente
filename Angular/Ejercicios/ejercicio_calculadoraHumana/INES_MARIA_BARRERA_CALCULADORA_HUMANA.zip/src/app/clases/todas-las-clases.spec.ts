import { TodasLasClases } from './todas-las-clases';

describe('TodasLasClases', () => {
  it('should create an instance', () => {
    expect(new TodasLasClases()).toBeTruthy();
  });
});
