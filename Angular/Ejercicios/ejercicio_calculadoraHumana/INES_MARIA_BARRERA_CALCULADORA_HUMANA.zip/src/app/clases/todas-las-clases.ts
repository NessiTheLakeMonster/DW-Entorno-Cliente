export class Persona {
    constructor(
        nombre: string,
        email: string,
    ) {
    }
}

export class Ranking {
    constructor(
        id: number,
        persona: Persona,
        puntos: number,
    ) {
    }
}
